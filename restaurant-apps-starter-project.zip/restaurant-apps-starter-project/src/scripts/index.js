import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

const mainElement = document.querySelector('main');
const heroElement = document.querySelector('.hero-container');
const drawerElement = document.querySelector('#drawer');

mainElement.addEventListener('click', event => {
  drawerElement.classList.remove('open');
  event.stopPropagation();
})

heroElement.addEventListener('click', event => {
  drawerElement.classList.remove('open');
  event.stopPropagation();
})

document.getElementById('hamburger').addEventListener('click', function() {
  drawerElement.classList.toggle('open');
});



// Custom element for displaying restaurant details
class PostItem extends HTMLElement {
  constructor() {
    super();
    // Shadow DOM
    const shadowRoot = this.attachShadow({ mode: 'open' });
    // Style for the component
    shadowRoot.innerHTML = `
    <style>
    .restaurant-list {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
    }
    
    .post-item {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
      border-radius: 15px;
      padding: 16px;
      background-color: white;
      display: flex;
      flex-direction: column;
    }
    
    .post-item img {
      width: 100%;
      max-height: 150px;
      object-fit: cover;
      border-top-left-radius: 15px;
      border-top-right-radius: 15px;
    }
    
    .post-item-content {
      padding: 16px;
      flex: 1;
    }
    
    .post-item h2 {
      margin: 0;
      margin-bottom: 10px;
      font-size: 1.5rem;
      color: #333;
    }
    
    .post-item .description {
      margin-bottom: 10px;
      color: #666;
      font-size: 16px;
    }

    .post-item-info {
      display: flex;
      justify-content: space-between;
    }
    
    .post-item .city {
      margin-bottom: 10px;
      color: #888;
    }
    
    .post-item .rating {
      color: #f90;
    }
    
    .post-item-container {
      text-decoration: none;
    }

    .post-item-container:focus {
      border: 10px solid aqua;
    }
    
    
      </style>


      <a href="#" class="post-item-container">
      <article class="post-item">
        <img class="pictureId" alt="Restaurant Picture">
        <div class="post-item-content">
        <h2></h2>
          <p class="description"></p>
          <div class="post-item-info">
          <p class="city"></p>
          <p class="rating"></p>
          </div>
        </div>
        </article>
        </a>      
    `;
  }

  connectedCallback() {
    // Get data from props
    const { name, description, pictureId, city, rating } = this.props;
    // Set data to the elements inside shadow DOM
    this.shadowRoot.querySelector('h2').textContent = name;
    this.shadowRoot.querySelector('.description').textContent = description;
    this.shadowRoot.querySelector('.pictureId').src = pictureId;
    this.shadowRoot.querySelector('.city').textContent = `City: ${city}`;
    this.shadowRoot.querySelector('.rating').textContent = `Rating: ${rating}`;
  }

  // Define props setter
  setProps(props) {
    this.props = props;
    // Update data when props change
    this.connectedCallback();
  }
}

// Define the custom element
customElements.define('post-item', PostItem);

// Function to render restaurants
function renderRestaurants(restaurants) {
  const restaurantListContainer = document.getElementById('restaurantList');
  restaurants.forEach(restaurant => {
    const postItem = document.createElement('post-item');
    postItem.setProps(restaurant);
    restaurantListContainer.appendChild(postItem);
  });
}

// Data restaurants
const restaurantsData = {
    "restaurants": [
      {
        "id": "6c7bqjgi84kcowlqdz",
        "name": "Bring Your Phone Cafe",
        "description": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/41",
        "city": "Medan",
        "rating": 4.6
      },
      {
        "id": "ljx8i0qu2uckcowlqdz",
        "name": "Run The Gun",
        "description": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/07",
        "city": "Bali",
        "rating": 4.6
      },
      {
        "id": "fe8bbxoazddkcowlqdz",
        "name": "Pangsit Express",
        "description": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/29",
        "city": "Ternate",
        "rating": 4.8
      },
      {
        "id": "ik1zljmlf68kcowlqdz",
        "name": "Ducky Duck",
        "description": "But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/38",
        "city": "Malang",
        "rating": 4.7
      },
      {
        "id": "9jpuzkm6n6jkcowlqdz",
        "name": "Kafein",
        "description": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/40",
        "city": "Bali",
        "rating": 3.8
      },
      {
        "id": "cpl5jpsnuqkkcowlqdz",
        "name": "Makan mudah",
        "description": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/08",
        "city": "Malang",
        "rating": 4.6
      },
      {
        "id": "iqtf9hmdzvbkcowlqdz",
        "name": "Saya Suka",
        "description": "But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/32",
        "city": "Surabaya",
        "rating": 3.6
      },
      {
        "id": "8i06gqcc2dpkcowlqdz",
        "name": "Gigitan Cepat",
        "description": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/45",
        "city": "Aceh",
        "rating": 4
      },
      {
        "id": "wf5o19xhxxkcowlqdz",
        "name": "Fairy Cafe",
        "description": "But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.",
        "pictureId": "https://restaurant-api.dicoding.dev/images/medium/04",
        "city": "Malang",
        "rating": 3.9
      }
    ]
  }
  
  

// Render restaurants
renderRestaurants(restaurantsData.restaurants);


